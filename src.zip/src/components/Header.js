import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/core/styles';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import MenuIcon from '@material-ui/icons/Menu';
import React from 'react';
import SwipeableTemporaryDrawer from './SwipeableTemporaryDrawer';
import { Link } from 'react-router-dom';


const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    grow: {
        flexGrow: 1,
    },
    menuButton: {
        marginLeft: -12,
        marginRight: 20,
    },
    logo: {
        flexGrow: 1,
    }
});


class Header extends React.Component {
    state = {
        left: false,
    }

    toggleDrawer = (side, open) => () => {
        this.setState({
            [side]: open,
        });
    };

    render() {
        const { classes } = this.props;

        return (
            <div>
                <SwipeableTemporaryDrawer open={this.state.left} onToggleDrawer={this.toggleDrawer} />
                <AppBar position="fixed">
                    <Toolbar>
                        <IconButton
onClick={this.toggleDrawer('left', true)}
                            className={classes.menuButton}
                            color="inherit"
                            aria-label="Menu"
                        >

                            <MenuIcon />
                        </IconButton>
                        <div className={classes.logo}>
                        <Button
                            component={linkProps => (
                                <Link {...linkProps} to="/" variant="button" />
                                )}
                                align="center">
                           
                            <Typography type="title" >
                                
                                <img
                                    className={classes.headerImage}
                                    src="/static/img/logo.svg"
                                    alt="Sig Tau"
                                    width="125"
                                    
                                    />
                            </Typography>
                        </Button>
                                    </div>
                        <Button color="inherit">Members</Button>
                    </Toolbar>
                </AppBar>
            </div>
        );
    }
}

export default withStyles(styles)(Header);
