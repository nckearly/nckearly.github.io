import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import MailIcon from '@material-ui/icons/MailOutline';
import PhoneIcon from '@material-ui/icons/Phone';
import PropTypes from 'prop-types';
import React from 'react';
import Typography from '../../../components/Typography';

const styles = theme => ({
  card: {
    display: 'inline-block',
    margin: theme.spacing.unit * 3,
    width: '17%',
    minWidth: 300,
  },
  title: {
    fontSize: 24,
    marginBottom: 5,
  },
  name: {
    fontSize: 19,
    marginBottom: 12,
  },
  contact: {
    display: 'flex',
    margin: theme.spacing.unit * 1,
  },
  contactText: {
    fontSize: 16,
    marginLeft: theme.spacing.unit * 2,
  },
});

function EducationCard(props) {
  const { classes } = props;

  return (
    <Card className={classes.card}>
      <CardContent>
        <Typography
          className={classes.title}
          align="left"
          variant="h5"
          marked="left"
        >
          Director of Finance
        </Typography>
        <Typography className={classes.name}>Ryan Melin</Typography>
        <Typography className={classes.contact}>
          <MailIcon />
          <span className={classes.contactText}>Rmelin@rams.colostate.edu</span>
        </Typography>
        <Typography className={classes.contact}>
          <PhoneIcon />
          <span className={classes.contactText}>(720) 989-7398</span>
        </Typography>
      </CardContent>
    </Card>
  );
}

EducationCard.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(EducationCard);
