import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../../components/Button';
import ProductHeroLayout from '../../components/ProductHeroLayout';
import Typography from '../../components/Typography';

const backgroundImage =
  "https://images.unsplash.com/photo-1475173641776-50e70b746de8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80";

const styles = theme => ({
    background: {
        backgroundImage: `url(${backgroundImage})`,
        backgroundColor: "0f07af", // Average color of the background image.
        backgroundPosition: "center",
    },
    button: {
        minWidth: 200,
    },
    h5: {
        marginBottom: theme.spacing.unit * 4,
        marginTop: theme.spacing.unit * 0,
        [theme.breakpoints.up("sm")]: {
            marginTop: theme.spacing.unit * 10,
        }
    },
    more: {
        marginTop: theme.spacing.unit * 2,
    },
    h1: {
        color: 'white',
        fontFamily: 'Ubuntu',
        fontWeight: 'bold',
        fontStyle: 'italic',
    },
    h2: {
        color: 'white',
        fontFamily: 'Ubuntu',
        fontWeight: 'bold',
        fontStyle: 'italic',
    },
});

function JoinHero(props) {
    const { classes } = props;

    return (
        <div className="Hero">
            <ProductHeroLayout
                backgroundClassName={classes.background}

            >
                {/* Increase the network loading priority of the background image. */}
                <img style={{ display: 'none' }} src={backgroundImage} alt="" />

                {
                    <React.Fragment>
                        
                        <div className={classes.h5}>
                            <Typography color="inherit" align="center" variant="h4">
                                See the Rush Schedule below for more info
              </Typography>
                            <br />
                            
                        </div>
                    </React.Fragment>
                }
                
            </ProductHeroLayout>
        </div>
    );
}

JoinHero.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(JoinHero);
