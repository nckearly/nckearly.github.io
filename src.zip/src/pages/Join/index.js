import { withStyles } from '@material-ui/core/styles';
import React from 'react';
import ProductHero from './JoinHero';
import Template from '../../components/PageTemplate';
import RushSchedule from '../../components/RushSchedule';
import Typography from '../../components/Typography';
import './styles.css';

const styles = theme => ({
  '@global': {},
  root: {
    flexGrow: 1,
  },
  Rush: {
    margin: theme.spacing.unit * 5,
  },
  
});

// eslint-disable-next-line react/prefer-stateless-function
class Join extends React.Component {
  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <Template>
          <ProductHero />
          <RushSchedule />
          
          <div className={classes.Rush}>
            <Typography variant="h5">
              Rushing is the first step in everyone's journey to join Sig Tau.
              We invite anyone and everyone to join us at our rush events in the
              schedule above.
            </Typography>
            <br />
            <Typography variant="h5">
              To receive a bid, you must attend at least <i>one</i> rush event.
              After which you will be contacted by our Director of Recruitment
              on how to proceed further
            </Typography>
            <br />
            <br />
            <Typography variant="h5">
              We wish you the best of luck in your rush process!
            </Typography>
          </div>
        </Template>
      </React.Fragment>
    );
  }
}

export default withStyles(styles)(Join);
