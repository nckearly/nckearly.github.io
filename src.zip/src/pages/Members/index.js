/* eslint-disable react/prefer-stateless-function */
import { withStyles } from '@material-ui/core';
import React from 'react';
import Template from '../../components/PageTemplate';
import Typography from '../../components/Typography';
import ProductHero from './MembersHero';
import './styles.css';
import TextField from '@material-ui/core/TextField';

const styles = theme => ({
  content: {
    margin: theme.spacing.unit * 4
  },
  body: {
    margin: theme.spacing.unit * 5
  },
  header: {
    marginBottom: theme.spacing.unit * 5
  },
  password: {
    display: "flex",
    justifyContent: "center",
  },
  TextField: {
    borderColor: "black",
    borderWidth: 50,
    width: 500,
  }
});

class App extends React.Component {
  render() {
    const { classes } = this.props;
    return (
      <Template>
        <ProductHero />
        <div className={classes.password}>
          <TextField
            id="standard-password-input"
            label="Password"
            className={classes.textField}
            type="password"
            autoComplete="current-password"
            margin="normal"
          />
        </div>
      </Template>
    );
  }
}

export default withStyles(styles)(App);
