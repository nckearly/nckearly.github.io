/* eslint-disable react/prefer-stateless-function */
import { withStyles } from '@material-ui/core';
import React from 'react';
import Template from '../../components/PageTemplate';
import Typography from '../../components/Typography';
import Community from '../Contact/Cards/Community';
import ProductHero from './OutreachHero';
import './styles.css';

const styles = theme => ({
  content: {
    margin: theme.spacing.unit * 4,
  },
  body: {
    margin: theme.spacing.unit * 5,
  },
  header: {
    marginBottom: theme.spacing.unit * 5,
  }
});

class App extends React.Component {
  render() {
    const { classes } = this.props;
    return (
      <Template>
        <ProductHero />
        <div className={classes.content}>
          <Typography className={classes.header} variant="h2" align="center" marked="center">
            Community Outreach
          </Typography>
          <Typography className={classes.body} variant="h5">
            Members of Sig Tau at colorado state volunteer a minimum of 10 hours
            every semester to help uphold our priciple of Community
            <br />
            Sig Tau currently supports a variety of local and national
            orginizations, such as:
            <ol id="list">
              <li>Ram Ride</li>
              <li>Special Olympics</li>
              <li>Off-Campus Life at Colorado State University </li>
              <li>Special Olympics at Colorado State University</li>
              <li>Sigma Tau Gamma Headquarters </li>
              <li>Fortitude 5k by Boulder Boulder </li>
              <li>And many more...</li>
            </ol>
            <br />
            Organizations and Companies looking for volunteers please contact
            our Director of Member and Community Engagement
            <br />
            <Community />
          </Typography>
        </div>
      </Template>
    );
  }
}

export default withStyles(styles)(App);
